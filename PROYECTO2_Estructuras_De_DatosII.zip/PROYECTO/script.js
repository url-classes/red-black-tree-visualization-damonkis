var NodeRBT = /** @class */ (function () {
    function NodeRBT(data, isLeaf) {
        this.data = data;
        this.color = isLeaf ? "BLACK" : "RED";
    }
    NodeRBT.prototype.getData = function () {
        return this.data;
    };
    NodeRBT.prototype.setFather = function (newFather) {
        this.father = newFather;
    };
    NodeRBT.prototype.getFather = function () {
        return this.father;
    };
    NodeRBT.prototype.setLeftChild = function (newChild) {
        this.leftChild = newChild;
    };
    NodeRBT.prototype.getLeftChild = function () {
        return this.leftChild;
    };
    NodeRBT.prototype.setRightChild = function (newChild) {
        this.rightChild = newChild;
    };
    NodeRBT.prototype.getRightChild = function () {
        return this.rightChild;
    };
    NodeRBT.prototype.setNodeAsRed = function () {
        this.color = "RED";
    };
    NodeRBT.prototype.setNodeAsBlack = function () {
        this.color = "BLACK";
    };
    NodeRBT.prototype.getColor = function () {
        return this.color;
    };
    return NodeRBT;
}());
var RBTree = /** @class */ (function () {
    function RBTree() {
        this.leaf = new NodeRBT(0, true);
        this.root = this.leaf;
    }
    RBTree.prototype.insert = function (data) {
        var newNode = new NodeRBT(data);
        var parent = this.leaf;
        var current = this.root;
        newNode.setLeftChild(this.leaf);
        newNode.setRightChild(this.leaf);
        while (current !== this.leaf) {
            parent = current;
            current = newNode.getData() < current.getData() ? current.getLeftChild() : current.getRightChild();
        }
        newNode.setFather(parent);
        if (parent === this.leaf) {
            this.root = newNode;
        }
        else if (newNode.getData() < parent.getData()) {
            parent.setLeftChild(newNode);
        }
        else {
            parent.setRightChild(newNode);
        }
        if (newNode.getFather() === this.leaf) {
            newNode.setNodeAsBlack();
            return;
        }
        if (newNode.getFather().getFather() == this.leaf)
            return;
        this.fixInsert(newNode);
    };
    RBTree.prototype.fixInsert = function (node) {
        while (node !== this.root && node.getFather().getColor() == "RED") {
            if (node.getFather() === node.getFather().getFather().getLeftChild()) {
                var uncle = node.getFather().getFather().getRightChild();
                if (uncle.getColor() === "RED") {
                    node.getFather().setNodeAsBlack();
                    uncle.setNodeAsBlack();
                    node.getFather().getFather().setNodeAsRed();
                    node = node.getFather().getFather();
                }
                else {
                    if (node === node.getFather().getRightChild()) {
                        node = node.getFather();
                        this.leftRotate(node);
                    }
                    node.getFather().setNodeAsBlack();
                    node.getFather().getFather().setNodeAsRed();
                    this.rightRotate(node.getFather().getFather());
                }
            }
            else {
                var uncle = node.getFather().getFather().getLeftChild();
                if (uncle.getColor() === "RED") {
                    node.getFather().setNodeAsBlack();
                    uncle.setNodeAsBlack();
                    node.getFather().getFather().setNodeAsRed();
                    node = node.getFather().getFather();
                }
                else {
                    if (node === node.getFather().getLeftChild()) {
                        node = node.getFather();
                        this.rightRotate(node);
                    }
                    node.getFather().setNodeAsBlack();
                    node.getFather().getFather().setNodeAsRed();
                    this.leftRotate(node.getFather().getFather());
                }
            }
        }
        this.root.setNodeAsBlack();
    };
    RBTree.prototype.leftRotate = function (x) {
        var y = x.getRightChild();
        x.setRightChild(y.getLeftChild());
        if (y.getLeftChild() != this.leaf)
            y.getLeftChild().setFather(x);
        y.setFather(x.getFather());
        if (x.getFather() == this.leaf)
            this.root = y;
        else if (x === x.getFather().getLeftChild())
            x.getFather().setLeftChild(y);
        else
            x.getFather().setRightChild(y);
        y.setLeftChild(x);
        x.setFather(y);
    };
    RBTree.prototype.rightRotate = function (x) {
        var y = x.getLeftChild();
        x.setLeftChild(y.getRightChild());
        if (y.getRightChild() != this.leaf)
            y.getRightChild().setFather(x);
        y.setFather(x.getFather());
        if (x.getFather() == this.leaf)
            this.root = y;
        else if (x === x.getFather().getRightChild())
            x.getFather().setRightChild(y);
        else
            x.getFather().setLeftChild(y);
        y.setRightChild(x);
        x.setFather(y);
    };
    RBTree.prototype.search = function (data) {
        var current = this.root;
        while (current !== this.leaf && current.getData() !== data) {
            current = data < current.getData() ? current.getLeftChild() : current.getRightChild();
        }
        return current;
    };
    RBTree.prototype.delete = function (data) {
        var node = this.search(data);
        if (node === this.leaf)
            return;
        var originalColor = node.getColor();
        var x;
        if (node.getLeftChild() === this.leaf) {
            x = node.getRightChild();
            this.transplant(node, node.getRightChild());
        }
        else if (node.getRightChild() === this.leaf) {
            x = node.getLeftChild();
            this.transplant(node, node.getLeftChild());
        }
        else {
            var successor = this.minimum(node.getRightChild());
            originalColor = successor.getColor();
            x = successor.getRightChild();
            if (successor.getFather() === node) {
                x.setFather(successor);
            }
            else {
                this.transplant(successor, successor.getRightChild());
                successor.setRightChild(node.getRightChild());
                successor.getRightChild().setFather(successor);
            }
            this.transplant(node, successor);
            successor.setLeftChild(node.getLeftChild());
            successor.getLeftChild().setFather(successor);
            successor.setNodeAsBlack();
        }
        if (originalColor === "BLACK") {
            this.fixDelete(x);
        }
    };
    RBTree.prototype.transplant = function (u, v) {
        if (u.getFather() === this.leaf)
            this.root = v;
        else if (u === u.getFather().getLeftChild())
            u.getFather().setLeftChild(v);
        else
            u.getFather().setRightChild(v);
        v.setFather(u.getFather());
    };
    RBTree.prototype.minimum = function (n) {
        while (n.getLeftChild() !== this.leaf)
            n = n.getLeftChild();
        return n;
    };
    RBTree.prototype.fixDelete = function (x) {
        while (x !== this.root && x.getColor() === "BLACK") {
            if (x === x.getFather().getLeftChild()) {
                var sibling = x.getFather().getRightChild();
                if (sibling.getColor() === "RED") {
                    sibling.setNodeAsBlack();
                    x.getFather().setNodeAsRed();
                    this.leftRotate(x.getFather());
                    sibling = x.getFather().getRightChild();
                }
                if (sibling.getLeftChild().getColor() === "BLACK" && sibling.getRightChild().getColor() === "BLACK") {
                    sibling.setNodeAsRed();
                    x = x.getFather();
                }
                else {
                    if (sibling.getRightChild().getColor() === "BLACK") {
                        sibling.getLeftChild().setNodeAsBlack();
                        sibling.setNodeAsRed();
                        this.rightRotate(sibling);
                        sibling = x.getFather().getRightChild();
                    }
                    sibling.setColor(x.getFather().getColor());
                    x.getFather().setNodeAsBlack();
                    sibling.getRightChild().setNodeAsBlack();
                    this.leftRotate(x.getFather());
                    x = this.root;
                }
            }
            else {
                var sibling = x.getFather().getLeftChild();
                if (sibling.getColor() === "RED") {
                    sibling.setNodeAsBlack();
                    x.getFather().setNodeAsRed();
                    this.rightRotate(x.getFather());
                    sibling = x.getFather().getLeftChild();
                }
                if (sibling.getLeftChild().getColor() === "BLACK" && sibling.getRightChild().getColor() === "BLACK") {
                    sibling.setNodeAsRed();
                    x = x.getFather();
                }
                else {
                    if (sibling.getLeftChild().getColor() === "BLACK") {
                        sibling.getRightChild().setNodeAsBlack();
                        sibling.setNodeAsRed();
                        this.leftRotate(sibling);
                        sibling = x.getFather().getLeftChild();
                    }
                    sibling.setColor(x.getFather().getColor());
                    x.getFather().setNodeAsBlack();
                    sibling.getLeftChild().setNodeAsBlack();
                    this.rightRotate(x.getFather());
                    x = this.root;
                }
            }
        }
        x.setNodeAsBlack();
    };
    // Dibuja el árbol usando D3.js
    RBTree.prototype.drawTree = function () {
        
        d3.select("#tree-canvas").selectAll("*").remove();
        var width = 600, height = 400;
        var svg = d3.select("#tree-canvas")
            .append("svg")
            .attr("width", width)
            .attr("height", height);
        var treeData = this.buildTreeData(this.root);
        var treeLayout = d3.tree().size([width - 50, height - 50]);
        var root = d3.hierarchy(treeData);
        treeLayout(root);
        svg.selectAll("line")
            .data(root.links())
            .enter()
            .append("line")
            .attr("x1", function (d) { return d.source.x; })
            .attr("y1", function (d) { return d.source.y; })
            .attr("x2", function (d) { return d.target.x; })
            .attr("y2", function (d) { return d.target.y; })
            .attr("stroke", "black");
        svg.selectAll("circle")
            .data(root.descendants())
            .enter()
            .append("circle")
            .attr("cx", function (d) { return d.x; })
            .attr("cy", function (d) { return d.y; })
            .attr("r", 15)
            .attr("fill", function (d) { return d.data.color; });
        svg.selectAll("text")
            .data(root.descendants())
            .enter()
            .append("text")
            .attr("x", function (d) { return d.x; })
            .attr("y", function (d) { return d.y + 4; })
            .attr("text-anchor", "middle")
            .attr("fill", "white")
            .text(function (d) { return d.data.data; });
    };
    RBTree.prototype.buildTreeData = function (node) {
        if (node === this.leaf)
            return null;
        return {
            data: node.getData(),
            color: node.getColor() === "BLACK" ? "black" : "red",
            children: [this.buildTreeData(node.getLeftChild()), this.buildTreeData(node.getRightChild())]
        };
    };
    return RBTree;
}());
// Inicialización y manejo de eventos
var tree = new RBTree();
document.getElementById("insert-node").addEventListener("click", function () {
    var value = parseInt(document.getElementById("node-value").value);
    if (!isNaN(value)) {
        tree.insert(value);
        tree.drawTree();
    }
});
document.getElementById("delete-node").addEventListener("click", function () {
    var value = parseInt(document.getElementById("node-value").value);
    if (!isNaN(value)) {
        tree.delete(value);
        tree.drawTree();
    }
});
document.getElementById("search-node").addEventListener("click", function () {
    var value = parseInt(document.getElementById("search-value").value);
    var result = tree.search(value);
    alert(result.getData() !== 0 ? "Nodo encontrado: ".concat(result.getData()) : "Nodo no encontrado");
});
